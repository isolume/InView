# Floors 2 and 3

Floor 2 is a clean reconstruction of the supplied synchronized video and LiDAR scan `CA3352E3-7C9E-465C-A643-CADF1385B3C9`. It includes the lounge, atrium balconies, gallery, restroom passage, and west seating area. Pale cutaway walls, blue-gray furniture and open metal railings keep it readable at map scale. Floor 3 remains the earlier estimated video reconstruction, unchanged.

Open `preview.html` for the interactive model, with floor selection, orbit, pan, zoom, and top view. Floor 2 is selected by default. The app uses the matching `student-center-east-floor-2-model.usdz` as its default Floor 2 model.

| File | Contents |
| --- | --- |
| `floor-2.glb` / `floor-2.usdz` | Updated Floor 2 model |
| `floor-3.glb` / `floor-3.usdz` | Retained Floor 3 model |
| `building.glb` / `building.usdz` | Both floors in the shared asset frame |
| `building.blend` | Editable Blender scene, separated into floor collections |
| `floor-2.png` / `floor-2-plan.png` | Cutaway and overhead previews |
| `layout.json` | Display landmarks and source provenance |
| `validation.json` / `glb-validation.json` | Native package, geometry and integration checks |

The recording contains 3,515 camera frames and 3,508 synchronized depth records over about 351.5 seconds. The structural fit uses high-confidence depth sampled across the entire walk, RoomPlan walls and openings, plus previous measured lounge geometry where the final scan dropped surfaces. Video identifies furnishings and materials; paired depth constrains their placement. Original source hashes and the compact, reproducible specification are in `../floor-2-reconstruction/`.

The floor silhouette is cleaned under furniture; furniture shapes and cutaway heights are styled. Local tracking drift remains, and the floor is flattened. The atrium and unobserved interiors are not filled in. The original routing map and Floor scan layer are preserved; the visual model does not establish new walking coverage, clearances, AR localization, or connections to Floor 3. The scan fit at the lounge is rigid, with 4.97 cm endpoint RMS; its agreement is local, not a survey accuracy claim for the entire floor.

The existing app registration maps authored coordinates back to scan meters. Exports are Y-up, Floor 2 at zero, Floor 3 at an estimated 4 meters. Blender source is Z-up. Lighting and the studio background are preview-only. Video imagery, people and personal belongings are not embedded.

## Rebuild

From the repository root, use Python with NumPy and Shapely 2.1 or newer, and Blender 4.5:

```sh
python3 scripts/prepare-video-lidar-floor-2.py
/Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python-exit-code 1 --python scripts/build-video-lidar-floor-2.py -- --samples 24
python3 scripts/build-walkthrough-floor-viewer.py
cp models/walkthrough-building/floors-2-3/floor-2.usdz InView/Resources/StudentCenter/student-center-east-floor-2-model.usdz
cp models/walkthrough-building/floors-2-3/floor-2.png InView/Resources/StudentCenter/student-center-east-floor-2-model.png
cp models/walkthrough-building/floors-2-3/layout.json InView/Resources/StudentCenter/student-center-east-model-layout.json
python3 scripts/validate-floor-models.py --check-app-resources
```

The prepared specification can be rebuilt directly in Blender without reprocessing the original 935 MiB video archive. `illustration-floors.json` belongs to the previous reconstruction and is kept for the legacy builder. `../floors-2-3-video.zip` remains the original video model and the source used to retain Floor 3.
